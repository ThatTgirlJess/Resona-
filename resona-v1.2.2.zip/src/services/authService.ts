/**
 * Client-Side Authentication Service for Resona
 * Manages secure user login, registration, token persistence, and auth state.
 */

import { VocalTrack } from '../types/voice';

export interface UserAccount {
  id: string;
  username: string;
  displayName: string;
  preferredTrack: VocalTrack;
  createdAt: string;
  lastLoginAt: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: UserAccount | null;
  token: string | null;
  isLoading: boolean;
}

const STORAGE_TOKEN = 'resona_auth_token';
const STORAGE_USER = 'resona_auth_user';

export class AuthService {
  private state: AuthState = {
    isAuthenticated: false,
    user: null,
    token: null,
    isLoading: true,
  };

  private listeners: ((state: AuthState) => void)[] = [];

  constructor() {
    this.initFromStorage();
  }

  private initFromStorage() {
    try {
      const token = localStorage.getItem(STORAGE_TOKEN);
      const userRaw = localStorage.getItem(STORAGE_USER);

      if (token && userRaw) {
        const user = JSON.parse(userRaw);
        this.state = {
          isAuthenticated: true,
          user,
          token,
          isLoading: false,
        };
        // Verify token in background with backend
        this.verifyToken(token).catch(() => {});
      } else {
        this.state.isLoading = false;
      }
    } catch {
      this.state.isLoading = false;
    }
  }

  public getState(): AuthState {
    return { ...this.state };
  }

  public subscribe(listener: (state: AuthState) => void): () => void {
    this.listeners.push(listener);
    listener(this.getState());
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      listener(this.getState());
    }
  }

  public getAuthHeader(): Record<string, string> {
    if (this.state.token) {
      return { Authorization: `Bearer ${this.state.token}` };
    }
    return {};
  }

  /**
   * Register a new user account
   */
  public async register(
    username: string,
    password: string,
    displayName: string,
    preferredTrack: VocalTrack = 'feminization'
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, displayName, preferredTrack }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to create account' };
      }

      this.saveSession(data.token, data.user);
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error during registration' };
    }
  }

  /**
   * Log in with username and password
   */
  public async login(
    username: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Invalid username or password' };
      }

      this.saveSession(data.token, data.user);
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message || 'Network error during login' };
    }
  }

  /**
   * Verify token validity with server
   */
  private async verifyToken(token: string): Promise<void> {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        this.state.user = data.user;
        localStorage.setItem(STORAGE_USER, JSON.stringify(data.user));
        this.notify();
      } else {
        // Token expired or invalid
        this.logout();
      }
    } catch {
      // Offline fallback: keep local session
    }
  }

  private saveSession(token: string, user: UserAccount) {
    this.state = {
      isAuthenticated: true,
      user,
      token,
      isLoading: false,
    };
    try {
      localStorage.setItem(STORAGE_TOKEN, token);
      localStorage.setItem(STORAGE_USER, JSON.stringify(user));
    } catch {}
    this.notify();
  }

  /**
   * Log out and revoke session
   */
  public async logout(): Promise<void> {
    if (this.state.token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: this.getAuthHeader(),
        });
      } catch {}
    }

    this.state = {
      isAuthenticated: false,
      user: null,
      token: null,
      isLoading: false,
    };

    try {
      localStorage.removeItem(STORAGE_TOKEN);
      localStorage.removeItem(STORAGE_USER);
    } catch {}

    this.notify();
  }
}

export const authService = new AuthService();
