/**
 * Dynamic Drill Progression Service
 * Implements an adaptive multi-tier mastery tree for vocal feminization and masculinization.
 * Dynamically scales exercise difficulty, calculates star ratings, and unlocks milestones based on user performance.
 */

import { VocalTrack, SessionRecord } from '../types/voice';
import { gamificationService } from './gamificationService';

export type MasteryStarRank = 'none' | 'bronze' | 'silver' | 'gold' | 'platinum';

export interface ProgressionDrillNode {
  id: string;
  tier: number;            // 1 to 5
  tierName: string;        // e.g. "Acoustic Foundation"
  title: string;
  category: 'resonance' | 'pitch' | 'weight' | 'inflection';
  track: VocalTrack;
  summary: string;
  targetMetricDesc: string;
  baseDurationSec: number;
  baseToleranceCents: number;
  unlocked: boolean;
  requiredPrevDrillId?: string;
  bestScore: number;
  starRank: MasteryStarRank;
  adaptiveLevel: number;   // 1 to 5 (dynamically scaled based on historical scores)
  adaptiveNotes: string;   // Human-readable rationale for current difficulty level
  repsCompleted: number;
  instructions: string[];
  physiologicalCues: string[];
}

export interface TrackProgressionState {
  track: VocalTrack;
  overallMasteryPercent: number;
  currentRankTitle: string;
  totalStarsEarned: number;
  maxPossibleStars: number;
  completedDrillCount: number;
  nodes: ProgressionDrillNode[];
  nextRecommendedDrillId: string;
}

const STORAGE_PROGRESSION_KEY = 'resona_drill_progression_v2';

// 5-Tier Master Tree Definition for Vocal Feminization
const FEMINIZATION_PROGRESSION_TREE: Omit<ProgressionDrillNode, 'unlocked' | 'bestScore' | 'starRank' | 'adaptiveLevel' | 'adaptiveNotes' | 'repsCompleted'>[] = [
  // TIER 1: Acoustic Foundation
  {
    id: 'fem-tier1-silent-siren',
    tier: 1,
    tierName: 'Tier 1: Acoustic Foundation',
    title: 'Silent Whisper Siren',
    category: 'resonance',
    track: 'feminization',
    summary: 'Elevate larynx and shorten pharynx without engaging vocal cord strain.',
    targetMetricDesc: 'Target bright oral resonance (>70%) on silent whisper.',
    baseDurationSec: 30,
    baseToleranceCents: 45,
    instructions: [
      'Inhale softly through your nose into the lower abdomen.',
      'Exhale on an unvoiced whisper, shaping a silent "ee".',
      'Smoothly glide your whisper from low to high whisper pitch.',
      'Feel your larynx float naturally toward your jaw without throat squeezing.',
    ],
    physiologicalCues: [
      'Thyrohyoid contraction elevates the larynx effortlessly.',
      'Tongue arches forward near upper molars.',
      'Keep neck strap muscles loose.',
    ],
  },
  {
    id: 'fem-tier1-dog-pant',
    tier: 1,
    tierName: 'Tier 1: Acoustic Foundation',
    title: 'Small Dog Pant (Larynx Mobility)',
    category: 'resonance',
    track: 'feminization',
    summary: 'Classical SLP exercise to isolate vocal tract length from vocal fold phonation.',
    targetMetricDesc: 'Maintain elevated resonance gauge (>72%) during light panting.',
    baseDurationSec: 35,
    baseToleranceCents: 45,
    requiredPrevDrillId: 'fem-tier1-silent-siren',
    instructions: [
      'Breathe like a small, excited puppy: gentle, silent air pulses.',
      'Place a gentle fingertip on your thyroid notch to feel it resting high.',
      'Transition into 3 soft voiced "hah" pulses on pitch ~210 Hz.',
    ],
    physiologicalCues: [
      'Shortens acoustic vocal tract length by 1.5–2 cm.',
      'Keep false vocal folds wide open (no raspy constriction).',
    ],
  },

  // TIER 2: Vocal Tract Resonance
  {
    id: 'fem-tier2-bright-vowels',
    tier: 2,
    tierName: 'Tier 2: Vocal Tract Resonance',
    title: 'Forward Oral Vowel Chain (/i/ → /e/)',
    category: 'resonance',
    track: 'feminization',
    summary: 'Train forward oral resonance across vowels without collapsing into throat resonance.',
    targetMetricDesc: 'Sustain F2 oral resonance above 75% across vowel transitions.',
    baseDurationSec: 45,
    baseToleranceCents: 35,
    requiredPrevDrillId: 'fem-tier1-dog-pant',
    instructions: [
      'Anchor on median feminine pitch (~215 Hz, A3).',
      'Sustain "ee" (/i/), feeling sound vibrate in the cheekbones and upper lip.',
      'Smoothly transition to "ay" (/e/), holding the exact same bright acoustic placement.',
    ],
    physiologicalCues: [
      'Tongue blade remains forward behind lower front teeth.',
      'Zygomatic cheek muscles provide subtle lift.',
    ],
  },

  // TIER 3: Pitch Stability Corridors
  {
    id: 'fem-tier3-laser-stability',
    tier: 3,
    tierName: 'Tier 3: Pitch Stability Corridors',
    title: 'Laser Pitch Stability Corridor',
    category: 'pitch',
    track: 'feminization',
    summary: 'Suppress involuntary vocal wobbles and micro-tremors in the 200–240 Hz zone.',
    targetMetricDesc: 'Achieve > 88% pitch stability score for sustained 15s phonation.',
    baseDurationSec: 45,
    baseToleranceCents: 25,
    requiredPrevDrillId: 'fem-tier2-bright-vowels',
    instructions: [
      'Target frequency: 215 Hz (A3).',
      'Take a silent diaphragmatic breath.',
      'Voice a steady "mmm" or "laaa", keeping the pitch cursor centered in the corridor.',
      'Maintain even abdominal breath pressure like blowing a slow, steady bubble.',
    ],
    physiologicalCues: [
      'Cricothyroid muscle maintains constant elongation.',
      'Eliminate tongue root tension to prevent pitch flutter.',
    ],
  },

  // TIER 4: Dynamic Vowel Bridges
  {
    id: 'fem-tier4-vowel-bridges',
    tier: 4,
    tierName: 'Tier 4: Dynamic Vowel Bridges',
    title: 'Thin-Fold Phonation & Vocal Weight Transition',
    category: 'weight',
    track: 'feminization',
    summary: 'Reduce heavy chest register contact for feather-light, clear feminine phonation.',
    targetMetricDesc: 'Keep vocal weight in the 25–40% range with >75% resonance.',
    baseDurationSec: 50,
    baseToleranceCents: 20,
    requiredPrevDrillId: 'fem-tier3-laser-stability',
    instructions: [
      'Say a soft "mm-hmm" as if kindly agreeing with a friend.',
      'Notice the feather-light, effortless sensation in your vocal folds.',
      'Carry that exact light weight into speaking words: "hello", "today", "wonderful".',
    ],
    physiologicalCues: [
      'Vibrates thin edges of the vocal folds (M2 register balance).',
      'Avoid pressing or squeezing into chest register.',
    ],
  },

  // TIER 5: Conversational Prosody & Agility
  {
    id: 'fem-tier5-prosody-reading',
    tier: 5,
    tierName: 'Tier 5: Conversational Prosody & Agility',
    title: 'Dynamic Upward Inflection Reading',
    category: 'inflection',
    track: 'feminization',
    summary: 'Practice natural feminine sentence intonation with rising phrase contours and bright cadence.',
    targetMetricDesc: 'Maintain pitch >= 200 Hz with melodic upward clause endings.',
    baseDurationSec: 60,
    baseToleranceCents: 18,
    requiredPrevDrillId: 'fem-tier4-vowel-bridges',
    instructions: [
      'Read the passage aloud with buoyant, musical inflection.',
      'Start sentences at median pitch (~205 Hz) and glide upward on key emotional words.',
      'Keep vocal weight light and airy—never slam downward into low chest tones.',
    ],
    physiologicalCues: [
      'Continuous pitch contour with expressive micro-glides.',
      'Check spectrograph: upper harmonics should dance gracefully.',
    ],
  },
];

// 5-Tier Master Tree Definition for Vocal Masculinization
const MASCULINIZATION_PROGRESSION_TREE: Omit<ProgressionDrillNode, 'unlocked' | 'bestScore' | 'starRank' | 'adaptiveLevel' | 'adaptiveNotes' | 'repsCompleted'>[] = [
  // TIER 1: Acoustic Foundation
  {
    id: 'masc-tier1-yawn-sigh',
    tier: 1,
    tierName: 'Tier 1: Acoustic Foundation',
    title: 'Yawn-Sigh Larynx Depression',
    category: 'resonance',
    track: 'masculinization',
    summary: 'Expand pharyngeal cavern and gently settle larynx for acoustic warmth.',
    targetMetricDesc: 'Target dark resonance (<30%) with rich low harmonics.',
    baseDurationSec: 35,
    baseToleranceCents: 45,
    instructions: [
      'Initiate a natural, relaxed silent yawn.',
      'Feel the wide, open cavern at the very back of your throat.',
      'At the peak of the yawn, sigh gently downward: "haaaaww" or "ohhhh".',
      'Feel deep reverberation in your sternum and collarbones.',
    ],
    physiologicalCues: [
      'Sternothyroid and omohyoid muscles settle larynx downward.',
      'Lengthens vocal tract by 2–3 cm.',
    ],
  },
  {
    id: 'masc-tier1-big-dog',
    tier: 1,
    tierName: 'Tier 1: Acoustic Foundation',
    title: 'Big Dog Breath (Pharyngeal Expansion)',
    category: 'resonance',
    track: 'masculinization',
    summary: 'Isolates pharyngeal expansion and maximum acoustic volume.',
    targetMetricDesc: 'Maintain dark resonance (<30%) and cavernous warmth.',
    baseDurationSec: 40,
    baseToleranceCents: 45,
    requiredPrevDrillId: 'masc-tier1-yawn-sigh',
    instructions: [
      'Open the back of your mouth as if biting into a giant apple.',
      'Breathe deeply like a heavy St. Bernard dog: slow, deep exhalations.',
      'Voice a relaxed, low "huh" or "woof" around 110 Hz.',
    ],
    physiologicalCues: [
      'Lowers F1 and F2 formants toward 400 Hz and 1000 Hz.',
      'Tongue root stays forward and soft.',
    ],
  },

  // TIER 2: Vocal Tract Resonance
  {
    id: 'masc-tier2-chest-vibration',
    tier: 2,
    tierName: 'Tier 2: Vocal Tract Resonance',
    title: 'Chest Bone Vibration Transfer',
    category: 'resonance',
    track: 'masculinization',
    summary: 'Train sympathetic chest resonance and thick vocal fold phonation on sustained open vowels.',
    targetMetricDesc: 'Target pitch 105–125 Hz with vocal weight >= 65%.',
    baseDurationSec: 45,
    baseToleranceCents: 35,
    requiredPrevDrillId: 'masc-tier1-big-dog',
    instructions: [
      'Place a flat palm firmly against the center of your sternum.',
      'Hum a relaxed "mmmm" around 100–120 Hz until your palm feels physical buzzing vibrations.',
      'Open into "mohh" or "maah", retaining the exact same chest buzzing.',
    ],
    physiologicalCues: [
      'Subglottic acoustic coupling with sternum.',
      'Dominant lower harmonic series below 500 Hz.',
    ],
  },

  // TIER 3: Pitch Stability Corridors
  {
    id: 'masc-tier3-pitch-grounding',
    tier: 3,
    tierName: 'Tier 3: Pitch Stability Corridors',
    title: 'Deep Pitch Grounding Anchor',
    category: 'pitch',
    track: 'masculinization',
    summary: 'Build steady pitch control and muscular endurance in the 90–120 Hz masculine range.',
    targetMetricDesc: 'Hold pitch between 95–125 Hz with > 88% stability.',
    baseDurationSec: 45,
    baseToleranceCents: 25,
    requiredPrevDrillId: 'masc-tier2-chest-vibration',
    instructions: [
      'Target frequency: 110 Hz (A2).',
      'Inhale deeply and ground your posture with shoulders relaxed.',
      'Sustain an authoritative, relaxed "bohh" or "noon".',
      'Keep the green pitch cursor steady without cracking or drifting.',
    ],
    physiologicalCues: [
      'Thyroarytenoid dominant (thick fold contact).',
      'Even subglottic air pressure.',
    ],
  },

  // TIER 4: Dynamic Vowel Bridges
  {
    id: 'masc-tier4-vowel-bridges',
    tier: 4,
    tierName: 'Tier 4: Dynamic Vowel Bridges',
    title: 'Dark Vowel Resonance Chain (/ɔ/ → /ɑ/ → /u/)',
    category: 'resonance',
    track: 'masculinization',
    summary: 'Maintain low larynx and pharyngeal space through open-to-closed vowel shifts.',
    targetMetricDesc: 'Maintain <32% resonance score through all 3 vowel shifts.',
    baseDurationSec: 50,
    baseToleranceCents: 20,
    requiredPrevDrillId: 'masc-tier3-pitch-grounding',
    instructions: [
      'Anchor at 115 Hz on "aww" (/ɔ/).',
      'Shift smoothly to "ah" (/ɑ/) by dropping jaw lower.',
      'Round lips into "ooh" (/u/) while keeping throat cavernously open.',
    ],
    physiologicalCues: [
      'Keeps larynx low throughout transitions.',
      'Prevents upward formant spikes.',
    ],
  },

  // TIER 5: Conversational Prosody & Agility
  {
    id: 'masc-tier5-falling-cadence',
    tier: 5,
    tierName: 'Tier 5: Conversational Prosody & Agility',
    title: 'Downward Terminal Pitch Grounding Passage',
    category: 'inflection',
    track: 'masculinization',
    summary: 'Practice masculine speech melody: steady plateaus with confident downward sentence-final falls.',
    targetMetricDesc: 'Keep average pitch <= 125 Hz with steady downward final cadence.',
    baseDurationSec: 60,
    baseToleranceCents: 18,
    requiredPrevDrillId: 'masc-tier4-vowel-bridges',
    instructions: [
      'Read the passage aloud with steady, grounded presence.',
      'Keep your speaking pitch between 100 Hz and 130 Hz.',
      'At the end of every sentence, allow your pitch to drop smoothly to your bottom resonance.',
    ],
    physiologicalCues: [
      'Controlled downward cadence.',
      'Full glottal contact throughout the phrase.',
    ],
  },
];

export class DrillProgressionService {
  /**
   * Load saved progression records from localStorage
   */
  private loadSavedProgression(): Record<string, { bestScore: number; reps: number }> {
    try {
      const raw = localStorage.getItem(STORAGE_PROGRESSION_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  /**
   * Save drill performance record and update stars/adaptive levels
   */
  public recordDrillScore(
    drillId: string,
    score: number
  ): { rankUp: boolean; newStar: MasteryStarRank; adaptiveLevel: number } {
    const saved = this.loadSavedProgression();
    const prevRecord = saved[drillId] || { bestScore: 0, reps: 0 };

    const newBest = Math.max(prevRecord.bestScore, score);
    const newReps = prevRecord.reps + 1;

    saved[drillId] = {
      bestScore: newBest,
      reps: newReps,
    };

    try {
      localStorage.setItem(STORAGE_PROGRESSION_KEY, JSON.stringify(saved));
    } catch {}

    const oldStar = this.calculateStarRank(prevRecord.bestScore);
    const newStar = this.calculateStarRank(newBest);
    const adaptiveLevel = this.calculateAdaptiveLevel(newBest, newReps);
    const rankUp = newStar !== oldStar;

    // Check if user earned new star bonus XP
    if (rankUp && newStar !== 'none') {
      const xpBonus = newStar === 'platinum' ? 80 : newStar === 'gold' ? 50 : newStar === 'silver' ? 30 : 15;
      gamificationService.addXp(xpBonus, `Mastery Star Unlocked: ${drillId}`);
    }

    return { rankUp, newStar, adaptiveLevel };
  }

  /**
   * Calculate star rank based on percentage score
   */
  public calculateStarRank(score: number): MasteryStarRank {
    if (score >= 95) return 'platinum';
    if (score >= 85) return 'gold';
    if (score >= 75) return 'silver';
    if (score >= 60) return 'bronze';
    return 'none';
  }

  /**
   * Calculate dynamic adaptive difficulty level (1 to 5)
   */
  public calculateAdaptiveLevel(bestScore: number, reps: number): number {
    if (bestScore >= 95 && reps >= 3) return 5;
    if (bestScore >= 90) return 4;
    if (bestScore >= 80) return 3;
    if (bestScore >= 65 || reps >= 2) return 2;
    return 1;
  }

  /**
   * Generate human-readable adaptive notes explaining current difficulty
   */
  public getAdaptiveNotes(level: number, bestScore: number): string {
    switch (level) {
      case 5:
        return 'Diamond Virtuoso: Corridor tightened by 35%, duration +20s. Peak endurance challenge!';
      case 4:
        return 'Advanced Mastery: Corridor tightened by 25%, duration +15s based on 90%+ score.';
      case 3:
        return 'Precision Tuning: Corridor tightened by 15% to build refined muscular control.';
      case 2:
        return 'Progressing: Target tolerances calibrated to encourage steady improvement.';
      default:
        return 'Foundational Calibration: Generous acoustic corridor to build muscle memory safely.';
    }
  }

  /**
   * Get complete track progression roadmap for UI
   */
  public getTrackProgression(track: VocalTrack, history: SessionRecord[] = []): TrackProgressionState {
    const rawTree = track === 'feminization' ? FEMINIZATION_PROGRESSION_TREE : MASCULINIZATION_PROGRESSION_TREE;
    const saved = this.loadSavedProgression();

    let totalStars = 0;
    let completedCount = 0;
    let nextRecommended = rawTree[0].id;
    let foundNext = false;

    const nodes: ProgressionDrillNode[] = rawTree.map((item, index) => {
      const record = saved[item.id] || { bestScore: 0, reps: 0 };

      // Also factor in matching sessions from history if any
      const matchingHist = history.filter((s) => s.drillId === item.id);
      let bestFromHistory = 0;
      if (matchingHist.length > 0) {
        bestFromHistory = Math.max(...matchingHist.map((s) => s.overallScore || 0));
      }
      const effectiveBest = Math.max(record.bestScore, bestFromHistory);

      // Unlock rules: first node always unlocked.
      // Subsequent nodes unlocked if previous required node has at least Bronze (score >= 60%)
      let isUnlocked = false;
      if (!item.requiredPrevDrillId) {
        isUnlocked = true;
      } else {
        const prevRec = saved[item.requiredPrevDrillId];
        const prevHist = history.filter((s) => s.drillId === item.requiredPrevDrillId);
        const prevBest = Math.max(prevRec?.bestScore || 0, ...prevHist.map((s) => s.overallScore || 0));
        isUnlocked = prevBest >= 60;
      }

      const starRank = this.calculateStarRank(effectiveBest);
      const adaptiveLevel = this.calculateAdaptiveLevel(effectiveBest, record.reps);
      const adaptiveNotes = this.getAdaptiveNotes(adaptiveLevel, effectiveBest);

      const starPoints = starRank === 'platinum' ? 4 : starRank === 'gold' ? 3 : starRank === 'silver' ? 2 : starRank === 'bronze' ? 1 : 0;
      totalStars += starPoints;

      if (effectiveBest >= 60) {
        completedCount++;
      }

      if (isUnlocked && effectiveBest < 85 && !foundNext) {
        nextRecommended = item.id;
        foundNext = true;
      }

      return {
        ...item,
        unlocked: isUnlocked,
        bestScore: effectiveBest,
        starRank,
        adaptiveLevel,
        adaptiveNotes,
        repsCompleted: record.reps,
      };
    });

    const maxStars = nodes.length * 4;
    const overallPercent = Math.round((totalStars / maxStars) * 100);

    let rankTitle = 'Vocal Explorer';
    if (overallPercent >= 90) rankTitle = 'Acoustic Virtuoso';
    else if (overallPercent >= 70) rankTitle = 'Harmonic Sculptor';
    else if (overallPercent >= 45) rankTitle = 'Resonance Artisan';
    else if (overallPercent >= 20) rankTitle = 'Acoustic Apprentice';

    return {
      track,
      overallMasteryPercent: overallPercent,
      currentRankTitle: rankTitle,
      totalStarsEarned: totalStars,
      maxPossibleStars: maxStars,
      completedDrillCount: completedCount,
      nodes,
      nextRecommendedDrillId: nextRecommended,
    };
  }
}

export const drillProgressionService = new DrillProgressionService();
