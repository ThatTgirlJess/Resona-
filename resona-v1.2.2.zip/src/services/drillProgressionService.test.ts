import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert';
import { DrillProgressionService } from './drillProgressionService.ts';

// Mock localStorage for node environment
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => store.get(key) || null,
    setItem: (key: string, value: string) => store.set(key, String(value)),
    removeItem: (key: string) => store.delete(key),
    clear: () => store.clear(),
    key: (index: number) => Array.from(store.keys())[index] || null,
    length: store.size,
  } as Storage;
}

describe('DrillProgressionService', () => {
  let service: DrillProgressionService;

  beforeEach(() => {
    localStorage.clear();
    service = new DrillProgressionService();
  });

  test('star rank calculations match performance thresholds', () => {
    assert.strictEqual(service.calculateStarRank(55), 'none');
    assert.strictEqual(service.calculateStarRank(62), 'bronze');
    assert.strictEqual(service.calculateStarRank(78), 'silver');
    assert.strictEqual(service.calculateStarRank(89), 'gold');
    assert.strictEqual(service.calculateStarRank(98), 'platinum');
  });

  test('adaptive level scales with scores and repetitions', () => {
    assert.strictEqual(service.calculateAdaptiveLevel(50, 0), 1);
    assert.strictEqual(service.calculateAdaptiveLevel(68, 1), 2);
    assert.strictEqual(service.calculateAdaptiveLevel(82, 2), 3);
    assert.strictEqual(service.calculateAdaptiveLevel(91, 2), 4);
    assert.strictEqual(service.calculateAdaptiveLevel(96, 4), 5);
  });

  test('initial track progression starts with node 1 unlocked and subsequent nodes locked', () => {
    const progression = service.getTrackProgression('feminization', []);
    assert.ok(progression.nodes.length >= 5, 'Should have at least 5 tiered nodes');

    // First node must be unlocked by default
    assert.strictEqual(progression.nodes[0].unlocked, true);
    // Second node requires node 1 completion, so locked initially
    assert.strictEqual(progression.nodes[1].unlocked, false);
    assert.strictEqual(progression.overallMasteryPercent, 0);
  });

  test('recording score unlocks subsequent tiered drills and updates star rank', () => {
    const firstNodeId = 'fem-tier1-silent-siren';
    const result = service.recordDrillScore(firstNodeId, 88);

    assert.strictEqual(result.rankUp, true);
    assert.strictEqual(result.newStar, 'gold');
    assert.strictEqual(result.adaptiveLevel, 3);

    // Now re-fetch progression
    const progression = service.getTrackProgression('feminization', []);
    assert.strictEqual(progression.nodes[0].bestScore, 88);
    assert.strictEqual(progression.nodes[0].starRank, 'gold');

    // Second node must now be unlocked!
    assert.strictEqual(progression.nodes[1].unlocked, true);
    assert.ok(progression.overallMasteryPercent > 0);
  });

  test('adaptive notes return informative clinical guidance', () => {
    const note1 = service.getAdaptiveNotes(1, 50);
    const note4 = service.getAdaptiveNotes(4, 92);
    assert.ok(note1.includes('Foundational'));
    assert.ok(note4.includes('Advanced Mastery'));
  });
});
