import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert';
import { AuthService } from './authService.ts';

// Mock localStorage for node environment
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => store.get(key) || null,
    setItem: (key: string, value: string) => store.set(key, String(value)),
    removeItem: (key: string) => store.delete(key),
    clear: () => store.clear(),
    key: (index: number) => Array.from(store.keys())[index] || null,
    length: store.size,
  } as Storage;
}

describe('AuthService State & Client Operations', () => {
  let auth: AuthService;

  beforeEach(() => {
    localStorage.clear();
    auth = new AuthService();
  });

  test('initial state is unauthenticated when storage is empty', () => {
    const state = auth.getState();
    assert.strictEqual(state.isAuthenticated, false);
    assert.strictEqual(state.user, null);
    assert.strictEqual(state.token, null);
    assert.deepStrictEqual(auth.getAuthHeader(), {});
  });

  test('subscription fires with current auth state', () => {
    let fired = false;
    const unsub = auth.subscribe((s) => {
      fired = true;
      assert.strictEqual(s.isAuthenticated, false);
    });
    assert.strictEqual(fired, true);
    unsub();
  });

  test('logout clears credentials and notifies subscribers', async () => {
    // Manually prime storage
    localStorage.setItem('resona_auth_token', 'test-token-123');
    localStorage.setItem(
      'resona_auth_user',
      JSON.stringify({
        id: 'u-1',
        username: 'testuser',
        displayName: 'Test User',
        preferredTrack: 'feminization',
        createdAt: '2026-01-01',
        lastLoginAt: '2026-01-01',
      })
    );

    const reloadedAuth = new AuthService();
    assert.strictEqual(reloadedAuth.getState().isAuthenticated, true);
    assert.strictEqual(reloadedAuth.getState().user?.username, 'testuser');
    assert.deepStrictEqual(reloadedAuth.getAuthHeader(), {
      Authorization: 'Bearer test-token-123',
    });

    await reloadedAuth.logout();
    assert.strictEqual(reloadedAuth.getState().isAuthenticated, false);
    assert.strictEqual(reloadedAuth.getState().token, null);
    assert.strictEqual(localStorage.getItem('resona_auth_token'), null);
  });
});
