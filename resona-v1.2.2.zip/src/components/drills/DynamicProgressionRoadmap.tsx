/**
 * Dynamic Progression Roadmap Component
 * Interactive visual skill tree displaying 5-tier vocal progression,
 * adaptive difficulty levels, star mastery ranks, and milestone unlocks.
 */

import React from 'react';
import { VocalTrack } from '../../types/voice';
import {
  TrackProgressionState,
  ProgressionDrillNode,
  MasteryStarRank,
} from '../../services/drillProgressionService';
import {
  Sparkles,
  Lock,
  Unlock,
  CheckCircle2,
  Award,
  Zap,
  TrendingUp,
  ArrowRight,
  ShieldCheck,
  Star,
  Play,
  Flame,
  Layers,
} from 'lucide-react';

interface DynamicProgressionRoadmapProps {
  progression: TrackProgressionState;
  onSelectDrill: (drill: ProgressionDrillNode) => void;
  track: VocalTrack;
}

export const DynamicProgressionRoadmap: React.FC<DynamicProgressionRoadmapProps> = ({
  progression,
  onSelectDrill,
  track,
}) => {
  const renderStarBadges = (rank: MasteryStarRank) => {
    switch (rank) {
      case 'platinum':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-xs">
            💎 Platinum Virtuoso
          </span>
        );
      case 'gold':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs">
            🥇 Gold Mastery
          </span>
        );
      case 'silver':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-300/20 text-slate-200 border border-slate-400/40 shadow-xs">
            🥈 Silver Proficient
          </span>
        );
      case 'bronze':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/20 text-orange-300 border border-orange-500/40 shadow-xs">
            🥉 Bronze Achieved
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-400 border border-slate-700">
            ⚪ Not Attempted
          </span>
        );
    }
  };

  const nextDrill = progression.nodes.find((n) => n.id === progression.nextRecommendedDrillId);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Mastery Progress Overview Card */}
      <div className="relative overflow-hidden p-6 rounded-3xl bg-linear-to-br from-slate-900 to-slate-950 border border-slate-800 shadow-xl space-y-4">
        <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-teal-500/15 text-teal-300 border border-teal-500/30">
                ⚡ Adaptive Mastery Tree
              </span>
              <span className="text-xs text-slate-400">
                {track === 'feminization' ? '🌸 Vocal Feminization Journey' : '🌲 Vocal Masculinization Journey'}
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <span>{progression.currentRankTitle}</span>
            </h3>
            <p className="text-xs text-slate-300 max-w-xl">
              Drill difficulty dynamically adapts to your pitch stability and resonance scores. Earn Bronze, Silver, Gold, and Platinum stars to advance through each physiological stage.
            </p>
          </div>

          {/* Quick Metrics Pills */}
          <div className="flex items-center gap-3">
            <div className="text-center px-4 py-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 shadow-inner">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Stars Earned</span>
              <span className="text-lg font-black text-amber-400 font-mono flex items-center justify-center gap-1">
                <Star className="w-4 h-4 fill-amber-400" />
                {progression.totalStarsEarned} / {progression.maxPossibleStars}
              </span>
            </div>

            <div className="text-center px-4 py-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 shadow-inner">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Track Mastery</span>
              <span className="text-lg font-black text-teal-300 font-mono">
                {progression.overallMasteryPercent}%
              </span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Stage Progress</span>
            <span className="text-teal-400 font-mono font-bold">{progression.completedDrillCount} of {progression.nodes.length} Milestones Complete</span>
          </div>
          <div className="w-full h-3 rounded-full bg-slate-950 border border-slate-800 overflow-hidden p-0.5">
            <div
              className="h-full rounded-full bg-linear-to-r from-teal-500 via-emerald-400 to-amber-400 transition-all duration-700 shadow-xs"
              style={{ width: `${Math.max(5, progression.overallMasteryPercent)}%` }}
            />
          </div>
        </div>

        {/* Next Recommended Adaptive Drill Hero Banner */}
        {nextDrill && (
          <div className="p-3.5 rounded-2xl bg-teal-950/40 border border-teal-500/30 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold">
                <Zap className="w-4 h-4 text-teal-400" />
              </div>
              <div>
                <span className="text-[10px] text-teal-300 font-semibold block uppercase tracking-wider">Next Recommended Milestone</span>
                <span className="font-bold text-white text-sm">{nextDrill.title}</span>
                <span className="text-slate-400 text-xs ml-2">({nextDrill.tierName})</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onSelectDrill(nextDrill)}
              className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all shadow-md hover:scale-105"
            >
              <span>Practice Now</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* 5-Tier Adaptive Mastery Tree Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <Layers className="w-4 h-4 text-teal-400" />
            <span>Physiological Progression Milestones</span>
          </h4>
          <span className="text-xs text-slate-400">Click any unlocked milestone to train</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {progression.nodes.map((node, index) => {
            const isCompleted = node.bestScore >= 60;

            return (
              <div
                key={node.id}
                className={`relative rounded-2xl border transition-all p-5 flex flex-col justify-between gap-4 ${
                  !node.unlocked
                    ? 'bg-slate-950/50 border-slate-800/60 opacity-60'
                    : isCompleted
                    ? 'bg-slate-900/90 border-slate-700/80 hover:border-teal-500/50 shadow-md'
                    : 'bg-slate-900 border-teal-500/30 hover:border-teal-400 shadow-md'
                }`}
              >
                {/* Node Top Header */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                      {node.tierName}
                    </span>
                    <div className="flex items-center gap-2">
                      {node.unlocked ? renderStarBadges(node.starRank) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-900 text-slate-500 border border-slate-800">
                          <Lock className="w-3 h-3" /> Locked
                        </span>
                      )}
                    </div>
                  </div>

                  <div>
                    <h5 className="font-extrabold text-white text-base tracking-tight flex items-center gap-1.5">
                      <span>{node.title}</span>
                      {isCompleted && <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />}
                    </h5>
                    <p className="text-xs text-slate-400 leading-relaxed mt-1">{node.summary}</p>
                  </div>
                </div>

                {/* Adaptive Calibration Box */}
                {node.unlocked && (
                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-teal-300 flex items-center gap-1">
                        <Zap className="w-3.5 h-3.5 text-teal-400" />
                        Adaptive Level {node.adaptiveLevel}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        Best: <strong className="text-white">{node.bestScore}%</strong> • Reps: {node.repsCompleted}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">
                      {node.adaptiveNotes}
                    </p>
                  </div>
                )}

                {/* Footer Action */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-mono">
                    Target: {node.baseDurationSec}s • {node.category}
                  </span>

                  {node.unlocked ? (
                    <button
                      type="button"
                      onClick={() => onSelectDrill(node)}
                      className="px-3.5 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs hover:scale-105"
                    >
                      <Play className="w-3.5 h-3.5 fill-slate-950" />
                      <span>{isCompleted ? 'Retrain Adaptive' : 'Start Milestone'}</span>
                    </button>
                  ) : (
                    <span className="text-[11px] text-slate-500 italic">
                      Unlock by completing Tier {node.tier - 1}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
