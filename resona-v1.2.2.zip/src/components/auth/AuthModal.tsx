/**
 * Authentication & Account Security Modal
 * Provides secure Login, Registration, Session Management,
 * and Password Security for Resona Voice Training.
 */

import React, { useState, useEffect } from 'react';
import { VocalTrack } from '../../types/voice';
import { authService, AuthState } from '../../services/authService';
import {
  ShieldCheck,
  User,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  LogOut,
  X,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ArrowRight,
  UserPlus,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTrack: VocalTrack;
  onTrackChange?: (track: VocalTrack) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentTrack,
  onTrackChange,
}) => {
  const [authState, setAuthState] = useState<AuthState>(authService.getState());
  const [tab, setTab] = useState<'login' | 'register'>('login');

  // Form Fields
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [preferredTrack, setPreferredTrack] = useState<VocalTrack>(currentTrack);
  const [showPassword, setShowPassword] = useState(false);

  // Status & Feedback
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const unsub = authService.subscribe((s) => {
      setAuthState(s);
    });
    return unsub;
  }, []);

  useEffect(() => {
    setPreferredTrack(currentTrack);
  }, [currentTrack]);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setIsSubmitting(true);

    const result = await authService.login(username, password);
    setIsSubmitting(false);

    if (result.success) {
      setSuccessMsg('Welcome back! Logged in securely.');
      setTimeout(() => {
        onClose();
        setSuccessMsg(null);
      }, 1200);
    } else {
      setErrorMsg(result.error || 'Login failed.');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setIsSubmitting(true);

    const result = await authService.register(username, password, displayName, preferredTrack);
    setIsSubmitting(false);

    if (result.success) {
      setSuccessMsg('Account created successfully!');
      if (onTrackChange) {
        onTrackChange(preferredTrack);
      }
      setTimeout(() => {
        onClose();
        setSuccessMsg(null);
      }, 1200);
    } else {
      setErrorMsg(result.error || 'Registration failed.');
    }
  };

  const handleLogout = async () => {
    await authService.logout();
    setSuccessMsg('Logged out successfully.');
    setTimeout(() => setSuccessMsg(null), 2000);
  };

  const fillDemoCredentials = () => {
    setUsername('demo_singer');
    setPassword('Resona2026!');
    setErrorMsg(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl p-6 sm:p-7 text-slate-100 flex flex-col gap-5">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-1/4 w-48 h-48 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 id="auth-modal-title" className="text-base font-bold text-white tracking-tight">
                {authState.isAuthenticated ? 'Account Security' : 'User Sign In'}
              </h2>
              <p className="text-[11px] text-slate-400">
                Secure Voice Profiles & Session Encryption
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* IF USER IS LOGGED IN: PROFILE & LOGOUT VIEW */}
        {authState.isAuthenticated && authState.user ? (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-full bg-linear-to-tr from-teal-500 to-emerald-400 flex items-center justify-center font-bold text-slate-950 text-base">
                    {authState.user.username.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="font-bold text-white text-sm flex items-center gap-1.5">
                      {authState.user.displayName}
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-teal-500/20 text-teal-300 border border-teal-500/40">
                        Verified
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 font-mono">@{authState.user.username}</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800/80">
                <div>
                  <span className="text-slate-500 block text-[10px]">Active Track</span>
                  <span className="font-semibold text-slate-200 capitalize">
                    {authState.user.preferredTrack === 'feminization' ? '🌸 Feminization' : '🌲 Masculinization'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Session Status</span>
                  <span className="font-semibold text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Encrypted
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={handleLogout}
                className="w-full px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="w-full px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* AUTH FORMS (LOGIN / REGISTER) */
          <div className="space-y-4">
            {/* Tab Switcher */}
            <div className="flex rounded-xl bg-slate-950 border border-slate-800 p-0.5 text-xs">
              <button
                type="button"
                onClick={() => {
                  setTab('login');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-1.5 rounded-lg font-semibold transition-all ${
                  tab === 'login'
                    ? 'bg-teal-500 text-slate-950 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Log In
              </button>
              <button
                type="button"
                onClick={() => {
                  setTab('register');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-1.5 rounded-lg font-semibold transition-all ${
                  tab === 'register'
                    ? 'bg-teal-500 text-slate-950 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Create Account
              </button>
            </div>

            {/* Error / Success Feedback Banners */}
            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}
            {successMsg && (
              <div className="p-2.5 rounded-xl bg-teal-950/60 border border-teal-500/40 text-teal-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-teal-400" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={tab === 'login' ? handleLogin : handleRegister} className="space-y-3">
              {tab === 'register' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Melody Star"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-teal-500 transition-colors"
                  />
                </div>
              )}

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Username
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. voice_explorer"
                    className="w-full pl-8.5 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-teal-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min. 6 characters"
                    className="w-full pl-8.5 pr-9 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-teal-500 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-2.5 text-slate-500 hover:text-slate-300"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {tab === 'register' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Primary Vocal Training Goal
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setPreferredTrack('feminization')}
                      className={`p-2 rounded-xl border text-center transition-all ${
                        preferredTrack === 'feminization'
                          ? 'bg-teal-500/20 border-teal-500 text-teal-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      🌸 Feminization
                    </button>
                    <button
                      type="button"
                      onClick={() => setPreferredTrack('masculinization')}
                      className={`p-2 rounded-xl border text-center transition-all ${
                        preferredTrack === 'masculinization'
                          ? 'bg-purple-500/20 border-purple-500 text-purple-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      🌲 Masculinization
                    </button>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md disabled:opacity-50"
              >
                <span>{isSubmitting ? 'Securing...' : tab === 'login' ? 'Sign In Securely' : 'Create Encrypted Account'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Quick Demo Credentials Autofill */}
            {tab === 'login' && (
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Need a quick test?</span>
                <button
                  type="button"
                  onClick={fillDemoCredentials}
                  className="text-teal-400 hover:text-teal-300 font-semibold underline underline-offset-2 flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Autofill Demo Account</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
