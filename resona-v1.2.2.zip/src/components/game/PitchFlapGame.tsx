/**
 * Flappy Pitch - Musical Staff Real-Time Pitch Matching Mini-Game
 * Controls an on-screen flying character by hitting specific musical notes on a staff in real time.
 * Supports live mic input, synthetic test voices, combo multipliers, and SLP resonance bonuses.
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { VocalTrack, VoiceMetrics } from '../../types/voice';
import { AvatarCustomization } from '../../services/gamificationService';
import { gamificationService } from '../../services/gamificationService';
import {
  pitchToStaffY,
  checkPitchMatch,
  calculateGateScore,
  generateMusicalGates,
  GateObstacle,
  GameDifficulty,
  GAME_DIFFICULTIES,
} from '../../utils/musicalStaff';
import { gameAudio } from '../../utils/gameAudio';
import { audioEngine, AudioSourceType } from '../../services/audioEngine';
import { hzToNote } from '../../utils/audioMath';
import {
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Flame,
  Trophy,
  Heart,
  Sparkles,
  Award,
  Zap,
  Music,
  ArrowUp,
  ArrowDown,
  Info,
  Sliders,
} from 'lucide-react';

interface PitchFlapGameProps {
  track: VocalTrack;
  metrics: VoiceMetrics;
  isAudioRunning: boolean;
  activeSource: AudioSourceType;
  onToggleMic: () => void;
  onSelectSynthetic: (source: AudioSourceType) => void;
  userAvatar?: AvatarCustomization;
}

const HIGH_SCORE_KEY = 'resona_flappy_pitch_highscore_v1';

export const PitchFlapGame: React.FC<PitchFlapGameProps> = ({
  track,
  metrics,
  isAudioRunning,
  activeSource,
  onToggleMic,
  onSelectSynthetic,
  userAvatar,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game Engine State
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'gameover'>('idle');
  const [difficultyKey, setDifficultyKey] = useState<string>('standard');
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(HIGH_SCORE_KEY);
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });
  const [lives, setLives] = useState<number>(3);
  const [combo, setCombo] = useState<number>(0);
  const [maxCombo, setMaxCombo] = useState<number>(0);
  const [gatesCleared, setGatesCleared] = useState<number>(0);
  const [resonanceBonuses, setResonanceBonuses] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [manualPitchOffset, setManualPitchOffset] = useState<number>(0);

  // Stats for gameover summary
  const [accuracyLog, setAccuracyLog] = useState<{ cents: number; match: boolean }[]>([]);

  // Refs for high-speed 60fps loop without React re-renders
  const stateRef = useRef({
    gameState: 'idle' as 'idle' | 'playing' | 'gameover',
    playerY: 200,
    playerTargetY: 200,
    playerX: 140,
    gates: [] as GateObstacle[],
    score: 0,
    combo: 0,
    maxCombo: 0,
    lives: 3,
    gatesCleared: 0,
    resonanceBonuses: 0,
    track,
    difficulty: GAME_DIFFICULTIES.standard,
    particles: [] as { x: number; y: number; vx: number; vy: number; life: number; color: string }[],
    staffScrollOffset: 0,
    lastFrameTime: performance.now(),
  });

  stateRef.current.track = track;
  stateRef.current.difficulty = GAME_DIFFICULTIES[difficultyKey] || GAME_DIFFICULTIES.standard;

  // Sync mute state
  useEffect(() => {
    gameAudio.setMuted(isMuted);
  }, [isMuted]);

  // Update high score in local storage
  const updateHighScore = useCallback((newScore: number) => {
    if (newScore > highScore) {
      setHighScore(newScore);
      try {
        localStorage.setItem(HIGH_SCORE_KEY, newScore.toString());
      } catch {}
    }
  }, [highScore]);

  // Start / Restart Game
  const startGame = () => {
    const canvas = canvasRef.current;
    const width = canvas ? canvas.width : 800;
    const height = canvas ? canvas.height : 420;

    const initialGates = generateMusicalGates(
      8,
      track,
      width,
      height,
      GAME_DIFFICULTIES[difficultyKey],
      width + 80
    );

    stateRef.current = {
      ...stateRef.current,
      gameState: 'playing',
      playerY: height * 0.6,
      playerTargetY: height * 0.6,
      playerX: 140,
      gates: initialGates,
      score: 0,
      combo: 0,
      maxCombo: 0,
      lives: 3,
      gatesCleared: 0,
      resonanceBonuses: 0,
      particles: [],
      staffScrollOffset: 0,
      lastFrameTime: performance.now(),
    };

    setScore(0);
    setCombo(0);
    setMaxCombo(0);
    setLives(3);
    setGatesCleared(0);
    setResonanceBonuses(0);
    setAccuracyLog([]);
    setGameState('playing');
  };

  // Keyboard controls for manual / accessibility testing
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'playing') return;
      if (e.key === 'ArrowUp' || e.key === 'w') {
        setManualPitchOffset((prev) => Math.min(prev + 18, 120));
      } else if (e.key === 'ArrowDown' || e.key === 's') {
        setManualPitchOffset((prev) => Math.max(prev - 18, -120));
      } else if (e.key === ' ') {
        e.preventDefault();
        setManualPitchOffset((prev) => (prev > 0 ? 0 : 50));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  // Main 60 FPS Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      const now = performance.now();
      const dt = Math.min((now - stateRef.current.lastFrameTime) / 1000, 0.1);
      stateRef.current.lastFrameTime = now;

      const { width, height } = canvas;
      const currentTrack = stateRef.current.track;
      const difficulty = stateRef.current.difficulty;

      // 1. UPDATE PLAYER TARGET Y BASED ON VOCAL PITCH OR MANUAL INPUT
      let effectivePitch = metrics.pitch;
      if (manualPitchOffset !== 0) {
        effectivePitch = Math.max(80, (effectivePitch > 0 ? effectivePitch : currentTrack === 'feminization' ? 220 : 120) + manualPitchOffset);
      }

      if (effectivePitch > 0) {
        stateRef.current.playerTargetY = pitchToStaffY(effectivePitch, currentTrack, height, 40);
      } else {
        // Natural gentle descent when silent
        stateRef.current.playerTargetY = Math.min(height * 0.85, stateRef.current.playerTargetY + 40 * dt);
      }

      // Smooth exponential interpolation (lerp) to avoid jittery movements
      const lerpSpeed = effectivePitch > 0 ? 12 : 5;
      stateRef.current.playerY += (stateRef.current.playerTargetY - stateRef.current.playerY) * Math.min(1, lerpSpeed * dt);

      // Clamp player Y within screen
      stateRef.current.playerY = Math.max(30, Math.min(height - 30, stateRef.current.playerY));

      // 2. CLEAR CANVAS & DRAW BACKGROUND MUSICAL STAFF
      ctx.fillStyle = '#090d16'; // Deep dark eye-care background
      ctx.fillRect(0, 0, width, height);

      // Staff Scroll Offset
      if (stateRef.current.gameState === 'playing') {
        stateRef.current.staffScrollOffset = (stateRef.current.staffScrollOffset + difficulty.speed) % 40;
      }

      // Draw horizontal staff lines (5 classical musical lines)
      const staffTop = height * 0.22;
      const staffSpacing = height * 0.12;
      ctx.lineWidth = 1.5;

      for (let i = 0; i < 5; i++) {
        const y = staffTop + i * staffSpacing;
        ctx.strokeStyle = i === 2 ? 'rgba(45, 212, 191, 0.35)' : 'rgba(148, 163, 184, 0.18)'; // Middle line highlighted
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();

        // Subtle staff note labels on the left margin
        ctx.fillStyle = 'rgba(148, 163, 184, 0.4)';
        ctx.font = '10px monospace';
        const lineNote = currentTrack === 'feminization'
          ? ['F5', 'D5', 'B4', 'G4', 'E4'][i]
          : ['A3', 'F3', 'D3', 'B2', 'G2'][i];
        ctx.fillText(lineNote, 8, y + 3);
      }

      // Draw Musical Clef on left margin
      ctx.fillStyle = currentTrack === 'feminization' ? 'rgba(45, 212, 191, 0.7)' : 'rgba(168, 85, 247, 0.7)';
      ctx.font = 'bold 36px serif';
      ctx.fillText(currentTrack === 'feminization' ? '𝄞' : '𝄢', 32, staffTop + staffSpacing * 3.2);

      // 3. DRAW AND UPDATE MUSICAL GATE OBSTACLES
      if (stateRef.current.gameState === 'playing') {
        const gates = stateRef.current.gates;
        const playerX = stateRef.current.playerX;
        const playerY = stateRef.current.playerY;

        for (let i = 0; i < gates.length; i++) {
          const gate = gates[i];
          gate.x -= difficulty.speed;

          // Target aperture bounds
          const gateTop = gate.targetY - gate.gapHeight / 2;
          const gateBottom = gate.targetY + gate.gapHeight / 2;

          // Draw Upper and Lower Pillar/Pipes styled as harmonic resonators
          const pipeColor = gate.isBonusResonance ? 'rgba(251, 191, 36, 0.25)' : 'rgba(56, 189, 248, 0.2)';
          const pipeBorder = gate.isBonusResonance ? '#f59e0b' : '#38bdf8';

          // Upper Pillar
          ctx.fillStyle = pipeColor;
          ctx.strokeStyle = pipeBorder;
          ctx.lineWidth = 2;
          ctx.fillRect(gate.x - gate.width / 2, 0, gate.width, gateTop);
          ctx.strokeRect(gate.x - gate.width / 2, 0, gate.width, gateTop);

          // Lower Pillar
          ctx.fillRect(gate.x - gate.width / 2, gateBottom, gate.width, height - gateBottom);
          ctx.strokeRect(gate.x - gate.width / 2, gateBottom, gate.width, height - gateBottom);

          // Safe Target Aperture (Glowing Musical Gateway)
          ctx.fillStyle = gate.isBonusResonance ? 'rgba(251, 191, 36, 0.12)' : 'rgba(45, 212, 191, 0.1)';
          ctx.fillRect(gate.x - gate.width / 2, gateTop, gate.width, gate.gapHeight);

          // Center target line
          ctx.strokeStyle = gate.isBonusResonance ? '#fbbf24' : '#2dd4bf';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(gate.x - gate.width / 2, gate.targetY);
          ctx.lineTo(gate.x + gate.width / 2, gate.targetY);
          ctx.stroke();
          ctx.setLineDash([]);

          // Target Note Badge on Gate
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(gate.x - 30, gate.targetY - 12, 60, 24);
          ctx.strokeStyle = gate.isBonusResonance ? '#fbbf24' : '#2dd4bf';
          ctx.strokeRect(gate.x - 30, gate.targetY - 12, 60, 24);

          ctx.fillStyle = gate.isBonusResonance ? '#fef08a' : '#ccfbf1';
          ctx.font = 'bold 11px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(gate.targetNote.note, gate.x, gate.targetY + 4);

          // Solfege sub-label
          ctx.fillStyle = 'rgba(203, 213, 225, 0.7)';
          ctx.font = '9px monospace';
          ctx.fillText(`${gate.targetNote.solfege} • ${Math.round(gate.targetNote.hz)}Hz`, gate.x, gate.targetY + 28);
          ctx.textAlign = 'left';

          // 4. COLLISION / PASS-THROUGH DETECTION
          const horizontalDistance = Math.abs(playerX - gate.x);

          if (horizontalDistance < gate.width / 2 && !gate.passed && !gate.hit) {
            // Check if player Y is inside safe aperture
            const isInsideGap = playerY >= gateTop && playerY <= gateBottom;

            // Pitch accuracy evaluation
            const pitchCheck = checkPitchMatch(
              effectivePitch > 0 ? effectivePitch : gate.targetNote.hz,
              gate.targetNote.hz,
              difficulty.toleranceCents
            );

            // Resonance bonus condition
            const hasResonanceBonus =
              gate.isBonusResonance &&
              ((currentTrack === 'feminization' && metrics.resonanceScore >= 65) ||
                (currentTrack === 'masculinization' && metrics.resonanceScore <= 40));

            if (isInsideGap || pitchCheck.matched) {
              // CLEAN PASS!
              gate.passed = true;
              const pointsEarned = calculateGateScore(pitchCheck.centsOff, stateRef.current.combo, hasResonanceBonus);
              gate.scoreAwarded = pointsEarned;

              stateRef.current.score += pointsEarned;
              stateRef.current.combo += 1;
              if (stateRef.current.combo > stateRef.current.maxCombo) {
                stateRef.current.maxCombo = stateRef.current.combo;
              }
              stateRef.current.gatesCleared += 1;

              if (hasResonanceBonus) {
                stateRef.current.resonanceBonuses += 1;
                gameAudio.playBonusResonance();
              } else {
                gameAudio.playGatePass(gate.targetNote.hz);
              }

              // Sparkle particles burst
              for (let p = 0; p < 14; p++) {
                stateRef.current.particles.push({
                  x: playerX,
                  y: playerY,
                  vx: (Math.random() - 0.5) * 160,
                  vy: (Math.random() - 0.5) * 160,
                  life: 0.6,
                  color: hasResonanceBonus ? '#fbbf24' : '#2dd4bf',
                });
              }

              setScore(stateRef.current.score);
              setCombo(stateRef.current.combo);
              setMaxCombo(stateRef.current.maxCombo);
              setGatesCleared(stateRef.current.gatesCleared);
              setResonanceBonuses(stateRef.current.resonanceBonuses);
              setAccuracyLog((prev) => [...prev, { cents: pitchCheck.centsOff, match: true }]);
            } else {
              // OBSTACLE HIT / COLLISION
              gate.hit = true;
              gameAudio.playObstacleHit();

              stateRef.current.lives -= 1;
              stateRef.current.combo = 0;
              setLives(stateRef.current.lives);
              setCombo(0);
              setAccuracyLog((prev) => [...prev, { cents: pitchCheck.centsOff, match: false }]);

              // Red thud particles
              for (let p = 0; p < 10; p++) {
                stateRef.current.particles.push({
                  x: playerX,
                  y: playerY,
                  vx: (Math.random() - 0.5) * 120,
                  vy: (Math.random() - 0.5) * 120,
                  life: 0.4,
                  color: '#f43f5e',
                });
              }

              // Game Over Check
              if (stateRef.current.lives <= 0) {
                stateRef.current.gameState = 'gameover';
                setGameState('gameover');
                updateHighScore(stateRef.current.score);
                gameAudio.playGameOver();

                // Award XP to gamification service!
                const earnedXp = Math.min(150, Math.floor(stateRef.current.score / 15) + 15);
                gamificationService.addXp(earnedXp, 'Flappy Pitch Mini-Game Mastery');
              }
            }
          }
        }

        // Remove off-screen gates and generate new ones
        const remainingGates = gates.filter((g) => g.x > -100);
        if (remainingGates.length < 5) {
          const lastGate = remainingGates[remainingGates.length - 1];
          const newGates = generateMusicalGates(
            4,
            currentTrack,
            width,
            height,
            difficulty,
            lastGate ? lastGate.x + difficulty.gateSpacing : width + 100
          );
          stateRef.current.gates = [...remainingGates, ...newGates];
        } else {
          stateRef.current.gates = remainingGates;
        }
      }

      // 5. UPDATE AND DRAW PARTICLES
      for (let p = stateRef.current.particles.length - 1; p >= 0; p--) {
        const pt = stateRef.current.particles[p];
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.life -= dt * 1.5;

        if (pt.life <= 0) {
          stateRef.current.particles.splice(p, 1);
        } else {
          ctx.fillStyle = pt.color;
          ctx.globalAlpha = Math.max(0, pt.life);
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 3 * pt.life, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1.0;
        }
      }

      // 6. DRAW PLAYER CHARACTER (VOICE AVATAR / SONGBIRD)
      const playerX = stateRef.current.playerX;
      const playerY = stateRef.current.playerY;

      // Sonic Trail behind character
      const trailGrad = ctx.createLinearGradient(playerX - 40, playerY, playerX, playerY);
      trailGrad.addColorStop(0, 'rgba(45, 212, 191, 0)');
      trailGrad.addColorStop(1, 'rgba(45, 212, 191, 0.45)');
      ctx.fillStyle = trailGrad;
      ctx.beginPath();
      ctx.moveTo(playerX, playerY - 8);
      ctx.lineTo(playerX - 45, playerY - 2);
      ctx.lineTo(playerX - 45, playerY + 2);
      ctx.lineTo(playerX, playerY + 8);
      ctx.fill();

      // Outer Aura Ring
      const isSinging = effectivePitch > 0;
      ctx.strokeStyle = isSinging ? '#2dd4bf' : 'rgba(148, 163, 184, 0.4)';
      ctx.lineWidth = isSinging ? 2.5 : 1.5;
      ctx.beginPath();
      ctx.arc(playerX, playerY, 18, 0, Math.PI * 2);
      ctx.stroke();

      // Character Head / Body
      ctx.fillStyle = userAvatar?.hairColor === 'hair-hologram-teal' ? '#14b8a6' : '#0d9488';
      ctx.beginPath();
      ctx.arc(playerX, playerY, 15, 0, Math.PI * 2);
      ctx.fill();

      // Flapping Wing Effect
      const flapAngle = Math.sin(now * 0.015) * 8;
      ctx.fillStyle = '#f0fdfa';
      ctx.beginPath();
      ctx.ellipse(playerX - 4, playerY + flapAngle * 0.3, 8, 4, Math.PI / 4, 0, Math.PI * 2);
      ctx.fill();

      // Eyes
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(playerX + 5, playerY - 3, 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Cute Beak / Singing Mouth
      if (isSinging) {
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(playerX + 14, playerY, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Musical note floating out of mouth
        ctx.fillStyle = '#2dd4bf';
        ctx.font = '12px serif';
        ctx.fillText('♪', playerX + 18, playerY - 8);
      } else {
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.moveTo(playerX + 13, playerY - 2);
        ctx.lineTo(playerX + 17, playerY);
        ctx.lineTo(playerX + 13, playerY + 2);
        ctx.fill();
      }

      // Live Pitch Label above character
      const currentNote = hzToNote(effectivePitch);
      ctx.fillStyle = isSinging ? '#2dd4bf' : '#94a3b8';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(
        isSinging ? `${currentNote.fullNote} (${Math.round(effectivePitch)}Hz)` : 'Sing to Fly',
        playerX,
        playerY - 24
      );
      ctx.textAlign = 'left';

      // 7. REQUEST NEXT FRAME
      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [metrics.pitch, metrics.resonanceScore, manualPitchOffset]);

  return (
    <div className="w-full space-y-4">
      {/* Top Game Navigation / HUD Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md text-xs">
        {/* Left: Brand & Lives */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-500/30 flex items-center justify-center font-bold">
            <Music className="w-4 h-4" />
          </div>
          <div>
            <div className="font-extrabold text-white text-sm flex items-center gap-2">
              Flappy Pitch
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Staff Runner
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              {track === 'feminization' ? '🌸 Treble Clef • 175–350 Hz' : '🌲 Bass Clef • 85–180 Hz'}
            </div>
          </div>

          {/* Lives Display */}
          <div className="flex items-center gap-1 pl-3 border-l border-slate-800">
            {[1, 2, 3].map((heartIndex) => (
              <Heart
                key={heartIndex}
                className={`w-4 h-4 transition-transform ${
                  heartIndex <= lives
                    ? 'text-rose-500 fill-rose-500 scale-110'
                    : 'text-slate-700 fill-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Center: Score & Combo Multiplier */}
        <div className="flex items-center gap-4">
          <div className="text-center">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Score</span>
            <span className="text-lg font-black text-white font-mono">{score}</span>
          </div>

          <div className="text-center">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">High Score</span>
            <span className="text-base font-bold text-amber-400 font-mono flex items-center justify-center gap-1">
              <Trophy className="w-3.5 h-3.5" />
              {highScore}
            </span>
          </div>

          {combo > 1 && (
            <div className="px-2.5 py-1 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-xs flex items-center gap-1 animate-pulse">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span>x{(1 + Math.min(combo * 0.1, 2.0)).toFixed(1)} Combo!</span>
            </div>
          )}
        </div>

        {/* Right: Difficulty & Audio Controls */}
        <div className="flex items-center gap-2">
          {/* Difficulty Selector */}
          <select
            value={difficultyKey}
            onChange={(e) => setDifficultyKey(e.target.value)}
            disabled={gameState === 'playing'}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-xl px-2.5 py-1.5 focus:outline-none"
            aria-label="Game difficulty level"
          >
            <option value="gentle">Gentle Cadence</option>
            <option value="standard">Acoustic Standard</option>
            <option value="virtuoso">Vocal Virtuoso</option>
          </select>

          {/* Sound Effects Toggle */}
          <button
            type="button"
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title={isMuted ? 'Unmute sounds' : 'Mute sounds'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Quick Mic Toggle */}
          <button
            type="button"
            onClick={onToggleMic}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all text-xs ${
              isAudioRunning && activeSource === 'mic'
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-teal-500 hover:bg-teal-400 text-slate-950 shadow-xs'
            }`}
          >
            {isAudioRunning && activeSource === 'mic' ? (
              <>
                <Mic className="w-3.5 h-3.5" /> Mic Live
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5" /> Start Mic
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Canvas Viewport with Overlay HUD */}
      <div className="relative w-full rounded-3xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl flex flex-col items-center">
        <canvas
          ref={canvasRef}
          width={820}
          height={420}
          className="w-full h-auto max-h-[500px] block cursor-pointer"
          onClick={() => {
            if (gameState !== 'playing') {
              startGame();
            }
          }}
        />

        {/* IDLE / START SCREEN OVERLAY */}
        {gameState === 'idle' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center text-slate-100 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shadow-lg">
              <Music className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                Flappy Pitch: Musical Staff Flight
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md">
                Control your vocal avatar by singing notes in real time. Higher pitch flies up; lower pitch glides down. Pass cleanly through glowing musical gates to score points!
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-300">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
                <Mic className="w-3.5 h-3.5 text-teal-400" />
                <span>Sing or Hum into Mic</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
                <ArrowUp className="w-3.5 h-3.5 text-teal-400" />
                <ArrowDown className="w-3.5 h-3.5 text-teal-400" />
                <span>Arrow Keys or Space (Fallback)</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Bonus Points for Target Resonance</span>
              </div>
            </div>

            <button
              type="button"
              onClick={startGame}
              className="px-6 py-3 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-sm flex items-center gap-2 shadow-lg transition-transform hover:scale-105"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Launch Flappy Pitch</span>
            </button>
          </div>
        )}

        {/* GAME OVER SCREEN OVERLAY */}
        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center text-slate-100 space-y-4 animate-fade-in">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
              <Trophy className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-white">Flight Complete!</h3>
              <p className="text-xs text-slate-400">Great vocal exercise session.</p>
            </div>

            {/* Scorecard Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-md text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Final Score</span>
                <span className="text-base font-bold text-teal-300 font-mono">{score}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Gates Cleared</span>
                <span className="text-base font-bold text-white font-mono">{gatesCleared}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Max Combo</span>
                <span className="text-base font-bold text-amber-400 font-mono">x{maxCombo}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Resonance Boosts</span>
                <span className="text-base font-bold text-purple-400 font-mono">{resonanceBonuses}</span>
              </div>
            </div>

            {/* Gamification XP Award Banner */}
            <div className="px-4 py-2 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs flex items-center gap-2">
              <Award className="w-4 h-4 text-teal-400" />
              <span>+{Math.min(150, Math.floor(score / 15) + 15)} XP awarded to your vocal level!</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={startGame}
                className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-transform hover:scale-105 shadow-md"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Play Again</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Controls & Demo Pitch Injector */}
      <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-slate-300 font-semibold">
            <Sliders className="w-4 h-4 text-teal-400" />
            <span>Interactive Pitch Testing & Synthesizers</span>
          </div>
          <span className="text-[11px] text-slate-400">
            Use these buttons to test flight notes without singing
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onSelectSynthetic('synth-fem')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 font-semibold flex items-center gap-1 transition-colors"
          >
            <span>Feminine High A3 (215Hz)</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectSynthetic('synth-masc')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 border border-slate-700 font-semibold flex items-center gap-1 transition-colors"
          >
            <span>Masculine Deep A2 (110Hz)</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectSynthetic('synth-siren')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-semibold flex items-center gap-1 transition-colors"
          >
            <span>Pitch Siren Glide</span>
          </button>

          {/* Quick keyboard jump helpers */}
          <div className="ml-auto flex items-center gap-1.5 text-slate-400">
            <span>Manual Trim:</span>
            <button
              type="button"
              onClick={() => setManualPitchOffset((p) => p + 20)}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold"
            >
              ▲ Higher
            </button>
            <button
              type="button"
              onClick={() => setManualPitchOffset((p) => p - 20)}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold"
            >
              ▼ Lower
            </button>
            {manualPitchOffset !== 0 && (
              <button
                type="button"
                onClick={() => setManualPitchOffset(0)}
                className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400 border border-slate-700 text-[11px]"
              >
                Reset
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
