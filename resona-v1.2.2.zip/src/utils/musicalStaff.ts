/**
 * Musical Staff Coordinate Mapping & Game Physics
 * Converts vocal pitch (Hz) to musical staff Y-coordinates,
 * generates melodic gate obstacles, and evaluates collision/accuracy.
 */

import { VocalTrack } from '../types/voice';
import { hzToNote, noteToHz } from './audioMath';

export interface StaffNote {
  note: string;       // e.g. "C4", "A3"
  hz: number;         // e.g. 261.63
  clef: 'treble' | 'bass';
  staffLineOffset: number; // 0 = middle line of staff, + = higher, - = lower
  solfege: string;    // "Do", "Re", "Mi", etc.
}

export interface GateObstacle {
  id: string;
  x: number;          // Horizontal position on canvas (pixels)
  width: number;      // Width of the gate aperture
  targetNote: StaffNote;
  targetY: number;    // Normalized staff Y position (0 = top, 1 = bottom)
  gapHeight: number;  // Height of the safe passage aperture (pixels)
  passed: boolean;
  hit: boolean;
  isBonusResonance: boolean;
  scoreAwarded?: number;
}

export interface GameDifficulty {
  id: 'gentle' | 'standard' | 'virtuoso';
  label: string;
  speed: number;           // Pixels per frame
  gapHeight: number;       // Size of gate aperture
  toleranceCents: number;  // Pitch tolerance in cents (100 cents = 1 semitone)
  gateSpacing: number;     // Distance between gates in pixels
}

export const GAME_DIFFICULTIES: Record<string, GameDifficulty> = {
  gentle: {
    id: 'gentle',
    label: 'Gentle (Beginner)',
    speed: 1.8,
    gapHeight: 90,
    toleranceCents: 50,
    gateSpacing: 340,
  },
  standard: {
    id: 'standard',
    label: 'Acoustic Standard',
    speed: 2.6,
    gapHeight: 70,
    toleranceCents: 35,
    gateSpacing: 290,
  },
  virtuoso: {
    id: 'virtuoso',
    label: 'Vocal Virtuoso',
    speed: 3.4,
    gapHeight: 52,
    toleranceCents: 20,
    gateSpacing: 250,
  },
};

// Common practice notes for Feminization (Treble Clef, 175 Hz - 330 Hz)
export const FEMININE_PRACTICE_NOTES: StaffNote[] = [
  { note: 'F3', hz: 174.61, clef: 'treble', staffLineOffset: -4, solfege: 'Fa' },
  { note: 'G3', hz: 196.00, clef: 'treble', staffLineOffset: -3, solfege: 'Sol' },
  { note: 'A3', hz: 220.00, clef: 'treble', staffLineOffset: -2, solfege: 'La' },
  { note: 'B3', hz: 246.94, clef: 'treble', staffLineOffset: -1, solfege: 'Ti' },
  { note: 'C4', hz: 261.63, clef: 'treble', staffLineOffset: 0, solfege: 'Do' },  // Middle C
  { note: 'D4', hz: 293.66, clef: 'treble', staffLineOffset: 1, solfege: 'Re' },
  { note: 'E4', hz: 329.63, clef: 'treble', staffLineOffset: 2, solfege: 'Mi' },
  { note: 'F4', hz: 349.23, clef: 'treble', staffLineOffset: 3, solfege: 'Fa' },
  { note: 'G4', hz: 392.00, clef: 'treble', staffLineOffset: 4, solfege: 'Sol' },
];

// Common practice notes for Masculinization (Bass Clef, 85 Hz - 175 Hz)
export const MASCULINE_PRACTICE_NOTES: StaffNote[] = [
  { note: 'E2', hz: 82.41, clef: 'bass', staffLineOffset: -4, solfege: 'Mi' },
  { note: 'F2', hz: 87.31, clef: 'bass', staffLineOffset: -3, solfege: 'Fa' },
  { note: 'G2', hz: 98.00, clef: 'bass', staffLineOffset: -2, solfege: 'Sol' },
  { note: 'A2', hz: 110.00, clef: 'bass', staffLineOffset: -1, solfege: 'La' },
  { note: 'B2', hz: 123.47, clef: 'bass', staffLineOffset: 0, solfege: 'Ti' },
  { note: 'C3', hz: 130.81, clef: 'bass', staffLineOffset: 1, solfege: 'Do' },
  { note: 'D3', hz: 146.83, clef: 'bass', staffLineOffset: 2, solfege: 'Re' },
  { note: 'E3', hz: 164.81, clef: 'bass', staffLineOffset: 3, solfege: 'Mi' },
  { note: 'F3', hz: 174.61, clef: 'bass', staffLineOffset: 4, solfege: 'Fa' },
];

/**
 * Maps pitch in Hz to a vertical coordinate (0 = top, height = bottom) on a musical staff canvas
 */
export function pitchToStaffY(
  pitchHz: number,
  track: VocalTrack,
  canvasHeight: number,
  padding: number = 40
): number {
  if (pitchHz <= 0 || !isFinite(pitchHz)) {
    // Resting position when silent (lower third of screen)
    return canvasHeight * 0.75;
  }

  // Define musical bounds per vocal track
  const minHz = track === 'feminization' ? 160 : 75;
  const maxHz = track === 'feminization' ? 380 : 190;

  // Clamped pitch in log2 scale (musical pitch is logarithmic)
  const clampedHz = Math.max(minHz, Math.min(maxHz, pitchHz));
  const logMin = Math.log2(minHz);
  const logMax = Math.log2(maxHz);
  const logVal = Math.log2(clampedHz);

  // Normalized 0 (low pitch) to 1 (high pitch)
  const normalized = (logVal - logMin) / (logMax - logMin);

  // Inverted: higher pitch should be higher on screen (lower Y pixel)
  const usableHeight = canvasHeight - padding * 2;
  return canvasHeight - padding - normalized * usableHeight;
}

/**
 * Checks if a vocal pitch matches a target note within tolerance in cents
 */
export function checkPitchMatch(
  currentHz: number,
  targetHz: number,
  toleranceCents: number
): { matched: boolean; centsOff: number } {
  if (currentHz <= 0 || targetHz <= 0) {
    return { matched: false, centsOff: 999 };
  }

  // Calculate difference in cents: 1200 * log2(f1 / f2)
  const centsOff = Math.round(1200 * Math.log2(currentHz / targetHz));
  const matched = Math.abs(centsOff) <= toleranceCents;

  return { matched, centsOff };
}

/**
 * Generates an array of randomized but melodic musical gates
 */
export function generateMusicalGates(
  count: number,
  track: VocalTrack,
  canvasWidth: number,
  canvasHeight: number,
  difficulty: GameDifficulty,
  startX: number = canvasWidth + 100
): GateObstacle[] {
  const notePool = track === 'feminization' ? FEMININE_PRACTICE_NOTES : MASCULINE_PRACTICE_NOTES;
  const gates: GateObstacle[] = [];

  let currentX = startX;
  let lastNoteIndex = Math.floor(notePool.length / 2);

  for (let i = 0; i < count; i++) {
    // Melodic progression: either step up/down (+-1) or skip (+-2)
    const stepOptions = [-2, -1, 0, 1, 2];
    const step = stepOptions[Math.floor(Math.random() * stepOptions.length)];
    let nextIndex = Math.max(0, Math.min(notePool.length - 1, lastNoteIndex + step));
    lastNoteIndex = nextIndex;

    const targetNote = notePool[nextIndex];
    const targetY = pitchToStaffY(targetNote.hz, track, canvasHeight);

    gates.push({
      id: `gate-${i}-${Date.now()}`,
      x: currentX,
      width: 48,
      targetNote,
      targetY,
      gapHeight: difficulty.gapHeight,
      passed: false,
      hit: false,
      isBonusResonance: Math.random() > 0.6, // 40% chance of being a bonus resonance gate
    });

    currentX += difficulty.gateSpacing;
  }

  return gates;
}

/**
 * Pure score calculator considering combo multiplier and accuracy
 */
export function calculateGateScore(
  centsOff: number,
  combo: number,
  hasBonusResonance: boolean
): number {
  const basePoints = 100;
  // Closer to 0 cents off = higher precision bonus
  const precisionMultiplier = Math.max(0.5, 1 - Math.abs(centsOff) / 100);
  const comboMultiplier = 1 + Math.min(combo * 0.1, 2.0); // max 3x combo
  const resonanceBonus = hasBonusResonance ? 50 : 0;

  return Math.round((basePoints * precisionMultiplier + resonanceBonus) * comboMultiplier);
}
