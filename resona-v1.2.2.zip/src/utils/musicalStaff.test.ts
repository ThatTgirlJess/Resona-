import { test, describe } from 'node:test';
import assert from 'node:assert';
import {
  pitchToStaffY,
  checkPitchMatch,
  calculateGateScore,
  generateMusicalGates,
  GAME_DIFFICULTIES,
  FEMININE_PRACTICE_NOTES,
  MASCULINE_PRACTICE_NOTES,
} from './musicalStaff.ts';

describe('MusicalStaff Physics & Game Calculations', () => {
  test('pitchToStaffY maps higher pitch to higher on screen (lower Y coordinate)', () => {
    const canvasHeight = 400;
    const lowY = pitchToStaffY(180, 'feminization', canvasHeight);
    const highY = pitchToStaffY(320, 'feminization', canvasHeight);

    assert.ok(highY < lowY, 'Higher pitch must map to a smaller Y pixel coordinate (higher up on screen)');
    assert.ok(highY >= 0 && highY <= canvasHeight, 'Y coordinate must stay within canvas bounds');
    assert.ok(lowY >= 0 && lowY <= canvasHeight, 'Low pitch must stay within canvas bounds');
  });

  test('pitchToStaffY resting position when silent', () => {
    const canvasHeight = 500;
    const restingY = pitchToStaffY(0, 'feminization', canvasHeight);
    assert.strictEqual(restingY, 500 * 0.75, 'Silent voice rests at 75% height');
  });

  test('checkPitchMatch identifies accurate note match within cents tolerance', () => {
    const targetHz = 261.63; // C4

    // Exact match
    const exact = checkPitchMatch(261.63, targetHz, 30);
    assert.strictEqual(exact.matched, true);
    assert.strictEqual(exact.centsOff, 0);

    // Slightly sharp but within 30 cents (approx +4 Hz at C4)
    const slightlySharp = checkPitchMatch(264, targetHz, 30);
    assert.strictEqual(slightlySharp.matched, true);
    assert.ok(slightlySharp.centsOff > 0);

    // Completely off (e.g. 350 Hz vs 261.63 Hz)
    const farOff = checkPitchMatch(350, targetHz, 30);
    assert.strictEqual(farOff.matched, false);
    assert.ok(farOff.centsOff > 100);

    // Inactive silence returns false
    const silent = checkPitchMatch(0, targetHz, 30);
    assert.strictEqual(silent.matched, false);
  });

  test('calculateGateScore scales with precision, combo, and resonance bonus', () => {
    const scoreBase = calculateGateScore(0, 0, false);
    const scoreCombo = calculateGateScore(0, 5, false);
    const scoreResonance = calculateGateScore(0, 0, true);

    assert.strictEqual(scoreBase, 100);
    assert.ok(scoreCombo > scoreBase, 'Combo must amplify score');
    assert.ok(scoreResonance > scoreBase, 'Resonance bonus must increase score');

    // Imprecise score should be lower than dead-center
    const impreciseScore = calculateGateScore(40, 0, false);
    assert.ok(impreciseScore < scoreBase, 'Imprecise note should give lower score');
  });

  test('generateMusicalGates creates sequentially spaced obstacles', () => {
    const gates = generateMusicalGates(5, 'feminization', 800, 450, GAME_DIFFICULTIES.standard, 900);
    assert.strictEqual(gates.length, 5);

    for (let i = 0; i < gates.length; i++) {
      assert.ok(gates[i].targetNote, 'Each gate must have a target note');
      assert.ok(gates[i].targetY > 0, 'Target Y must be positive');
      assert.strictEqual(gates[i].gapHeight, GAME_DIFFICULTIES.standard.gapHeight);

      if (i > 0) {
        assert.ok(gates[i].x > gates[i - 1].x, 'Gates must be sequentially spaced along X-axis');
      }
    }
  });

  test('practice note pools contain valid pitches', () => {
    assert.ok(FEMININE_PRACTICE_NOTES.length >= 7);
    assert.ok(MASCULINE_PRACTICE_NOTES.length >= 7);

    for (const n of FEMININE_PRACTICE_NOTES) {
      assert.ok(n.hz > 150 && n.hz < 450, 'Fem note range check');
      assert.strictEqual(n.clef, 'treble');
    }

    for (const n of MASCULINE_PRACTICE_NOTES) {
      assert.ok(n.hz > 70 && n.hz < 200, 'Masc note range check');
      assert.strictEqual(n.clef, 'bass');
    }
  });
});
